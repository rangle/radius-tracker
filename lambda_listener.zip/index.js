"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const buffer_1 = require("buffer");
const rest_1 = require("@octokit/rest");
global.Buffer = buffer_1.Buffer; // TODO: provide via webpack globals
const octokit = new rest_1.Octokit();
exports.handler = (event) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    console.log("LAMBDA executed with", event.body);
    const githubUrl = event.body;
    const url = new URL(githubUrl);
    console.log("LAMBDA executed url", url);
    if (url.hostname !== "github.com") {
        return responseEvent({
            statusCode: 400, payload: "github.com url expected",
        });
    }
    const [, owner, repo] = url.pathname.split("/");
    console.log("LAMBDA executed owner, repo", owner, repo);
    if (!owner || !repo) {
        return responseEvent({
            statusCode: 400, payload: "Url does not point to a github repo",
        });
    }
    const repoInfo = yield octokit.repos.get({ owner, repo });
    console.log("LAMBDA executed owner, repoInfo");
    // invoke next function with reoiInfo
    return responseEvent({
        statusCode: 200, payload: repoInfo.data.clone_url,
    });
});
function responseEvent(response) {
    const headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
    };
    return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
            payload: response.payload,
            code: response.statusCode,
        }),
    };
}
